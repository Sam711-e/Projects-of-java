import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Student stu1 = new Student();

        System.out.println("Generated Student ID: " + stu1.getId());

        System.out.print("Enter the name of the student: ");
        stu1.name = input.nextLine();

        System.out.print("Enter the number of subjects: ");
        int subjectCount = input.nextInt();
        input.nextLine();

        ArrayList<Double> grades = new ArrayList<>();
        Map<String, Double> subjectMap = new LinkedHashMap<>();
        List<String> failedSubjects = new ArrayList<>();

        for (int i = 1; i <= subjectCount; i++) {
            System.out.print("Enter the name of subject " + i + ": ");
            String subjectName = input.nextLine();

            System.out.print("Enter the grade for \"" + subjectName + "\": ");
            double grade = input.nextDouble();
            input.nextLine(); // تفريغ السطر

            if (grade >= 0 && grade <= 100) {
                grades.add(grade);
                subjectMap.put(subjectName, grade);

                if (grade < 50) {
                    failedSubjects.add(subjectName + " (failed)");
                }
            } else {
                System.out.println("Invalid grade. Please enter a value between 0 and 100.");
                i--;
            }
        }

        stu1.findDig(grades);
        stu1.printData();

        System.out.println("\n--- Subject Grades ---");
        for (Map.Entry<String, Double> entry : subjectMap.entrySet()) {
            System.out.printf("%s: %.1f\n", entry.getKey(), entry.getValue());
        }

        if (!failedSubjects.isEmpty()) {
            System.out.println("\nFailed subjects:");
            for (String subject : failedSubjects) {
                System.out.println("- " + subject);
            }
        } else {
            System.out.println("\nNo failed subjects.");
        }
    }
}
