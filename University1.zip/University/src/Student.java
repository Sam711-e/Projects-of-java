import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

public class Student {
    String name;
    private final String id;
    private double average;

    public Student() {
        this.id = generateId();
    }

    private String generateId() {
        Random rand = new Random();
        Set<Integer> digits = new LinkedHashSet<>();
        while (digits.size() < 5) {
            digits.add(rand.nextInt(10));
        }
        StringBuilder sb = new StringBuilder("2025");
        for (int d : digits) {
            sb.append(d);
        }
        return sb.toString();
    }

    public void findDig(ArrayList<Double> grades) {
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        average = grades.isEmpty() ? 0 : sum / grades.size();
    }

    private String getRatingInternal() {
        if (average >= 90) return "Excellent";
        else if (average >= 80) return "Very Good";
        else if (average >= 70) return "Good";
        else if (average >= 60) return "Fair";
        else if (average >= 50) return "Pass";
        else return "Fail";
    }

    public void printData() {
        boolean isPassed = average >= 50;
        System.out.println("\n--- Student Report ---");
        System.out.println("Name     : " + name);
        System.out.println("ID       : " + id);
        System.out.printf("Average  : %.1f\n", average);
        System.out.println("Status   : " + (isPassed ? "Passed" : "Failed"));
        System.out.println("Rating   : " + getRatingInternal());
    }

    public String getId() {
        return id;
    }

    public double getAverage() {
        return average;
    }

    public String getRating() {
        return getRatingInternal();
    }
}
